const { serverClient, requireAdmin } = require('./_supabase');
function normalize(v) { return String(v ?? '').trim().toLowerCase().replace(/\s+/g, ' '); }

module.exports = async function handler(req, res) {
  try { await requireAdmin(req); } catch (e) {
    return res.status(e.message === 'FORBIDDEN' ? 403 : 401).json({ error: e.message === 'FORBIDDEN' ? 'Admin access required.' : 'Unauthorized.' });
  }
  const supabase = serverClient();
  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('people').select('id,name,description,image_url,created_at,updated_at').order('name');
      if (error) throw error;
      return res.json(data);
    }
    if (req.method === 'POST') {
      const { id, name, description, image_url } = req.body || {};
      if (!String(name || '').trim()) return res.status(400).json({ error: 'Name is required.' });
      const row = { name: String(name).trim(), description: String(description || '').trim(), image_url: String(image_url || '').trim() || null };
      if (id) row.id = id;
      const { data, error } = await supabase.from('people').upsert(row, { onConflict: 'name_key' }).select().single();
      if (error) throw error;
      return res.json({ ok: true, record: data });
    }
    if (req.method === 'DELETE') {
      const id = String(req.query.id || '');
      if (!id) return res.status(400).json({ error: 'ID is required.' });
      const { error } = await supabase.from('people').delete().eq('id', id);
      if (error) throw error;
      return res.json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: e.message || 'Server error' });
  }
};
