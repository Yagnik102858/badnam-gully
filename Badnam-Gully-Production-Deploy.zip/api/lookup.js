const { serverClient } = require('./_supabase');

function normalize(v) { return String(v ?? '').trim().toLowerCase().replace(/\s+/g, ' '); }

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const query = normalize(req.body?.name);
    if (!query) return res.status(400).json({ error: 'Please enter a name.' });

    const supabase = serverClient();
    const { data, error } = await supabase
      .from('people')
      .select('name,description,image_url')
      .eq('name_key', query)
      .maybeSingle();

    if (error) throw error;
    if (!data) return res.status(404).json({ found: false });

    // Only the requested record leaves the server. No roster/list endpoint is public.
    return res.status(200).json({ found: true, name: data.name, description: data.description, image: data.image_url || null });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
};
