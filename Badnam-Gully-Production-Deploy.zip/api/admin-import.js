const XLSX = require('xlsx');
const { serverClient, requireAdmin } = require('./_supabase');
function normalize(v) { return String(v ?? '').trim().toLowerCase().replace(/\s+/g, ' '); }
module.exports = async function handler(req, res) {
  try { await requireAdmin(req); } catch (e) {
    return res.status(e.message === 'FORBIDDEN' ? 403 : 401).json({ error: e.message === 'FORBIDDEN' ? 'Admin access required.' : 'Unauthorized.' });
  }
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { base64 } = req.body || {};
    if (!base64) return res.status(400).json({ error: 'Excel file is required.' });
    const buffer = Buffer.from(base64, 'base64');
    const wb = XLSX.read(buffer, { type: 'buffer' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });
    const people = rows.map(r => ({
      name: String(r.Name ?? '').trim(),
      description: String(r.Description ?? '').trim(),
      image_url: String(r.Image ?? '').trim() || null
    })).filter(r => r.name);
    if (!people.length) return res.status(400).json({ error: 'No rows found. Expected Name, Description and Image columns.' });
    const supabase = serverClient();
    const { error } = await supabase.from('people').upsert(people, { onConflict: 'name_key' });
    if (error) throw error;
    return res.json({ ok: true, imported: people.length });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: e.message || 'Excel import failed.' });
  }
};
