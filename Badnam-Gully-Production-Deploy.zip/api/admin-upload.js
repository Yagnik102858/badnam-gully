const { serverClient, requireAdmin } = require('./_supabase');

module.exports = async function handler(req, res) {
  try { await requireAdmin(req); } catch (e) {
    return res.status(e.message === 'FORBIDDEN' ? 403 : 401).json({ error: e.message === 'FORBIDDEN' ? 'Admin access required.' : 'Unauthorized.' });
  }
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { filename, contentType, base64 } = req.body || {};
    if (!base64) return res.status(400).json({ error: 'No image supplied.' });
    const allowed = ['image/jpeg','image/png','image/webp','image/gif'];
    if (!allowed.includes(contentType)) return res.status(400).json({ error: 'Use JPG, PNG, WEBP or GIF.' });
    const buffer = Buffer.from(base64, 'base64');
    if (buffer.length > 5 * 1024 * 1024) return res.status(400).json({ error: 'Image must be 5 MB or smaller.' });
    const safe = String(filename || 'photo').replace(/[^a-zA-Z0-9._-]/g, '_');
    const path = `${Date.now()}-${safe}`;
    const supabase = serverClient();
    const { error } = await supabase.storage.from(process.env.SUPABASE_STORAGE_BUCKET || 'farewell-images').upload(path, buffer, { contentType, upsert: false });
    if (error) throw error;
    const { data } = supabase.storage.from(process.env.SUPABASE_STORAGE_BUCKET || 'farewell-images').getPublicUrl(path);
    return res.json({ ok: true, image_url: data.publicUrl });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Image upload failed.' });
  }
};
