const { createClient } = require('@supabase/supabase-js');

function serverClient() {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
}

function browserClient() {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY);
}

async function requireAdmin(req) {
  const auth = req.headers.authorization || '';
  if (!auth.startsWith('Bearer ')) throw new Error('UNAUTHORIZED');
  const token = auth.slice(7);
  const supabase = browserClient();
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) throw new Error('UNAUTHORIZED');
  if (!process.env.ADMIN_EMAIL || data.user.email?.toLowerCase() !== process.env.ADMIN_EMAIL.toLowerCase()) {
    throw new Error('FORBIDDEN');
  }
  return data.user;
}

module.exports = { serverClient, requireAdmin };
