# Badnam Gully — Production Farewell Archive

A deploy-ready farewell site using **Vercel + Supabase**.

## What this version gives you

- Public shareable website with the BADNAM GULLY experience.
- Exact, case-insensitive name lookup.
- The browser never downloads the complete colleague roster.
- Supabase Postgres stores names, descriptions and image URLs.
- Supabase Auth protects the owner console.
- Only the email in `ADMIN_EMAIL` can use the admin API.
- Admin can create, edit and delete memories.
- Admin can upload colleague photos (stored in Supabase Storage).
- Admin can import your Excel file with columns `Name`, `Description`, `Image`.
- HTTPS and deployment handled by Vercel.

Vercel supports Node.js server deployments and serverless functions; Supabase provides Postgres, Auth and Storage.

## 1. Create Supabase project

1. Open the Supabase dashboard and create a project.
2. Open **SQL Editor**.
3. Paste the complete contents of `supabase/schema.sql` and run it.
4. Open **Authentication → Users** and create your owner user using your email and a strong password.
5. The email must match `ADMIN_EMAIL` in Vercel.
6. The SQL creates the `farewell-images` public bucket. Image uploads are performed server-side with the Supabase service role key.

Supabase recommends Row Level Security when exposing database access; this project keeps the `people` table closed to browser clients and performs both public lookups and admin mutations through server APIs.

## 2. Deploy to Vercel

### Easiest method

1. Create a GitHub repository, for example `badnam-gully-farewell`.
2. Upload this entire project to that repository.
3. Open Vercel and choose **Add New → Project**.
4. Import the GitHub repository.
5. Deploy.

Vercel's dashboard can import a Git repository and deploy it as a live project. citeturn0search15

### Environment variables

In **Vercel → Project → Settings → Environment Variables**, add:

```text
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_SERVICE_ROLE_KEY=YOUR_SUPABASE_SERVICE_ROLE_KEY
SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
ADMIN_EMAIL=your-email@example.com
SUPABASE_STORAGE_BUCKET=farewell-images
```

**Never put `SUPABASE_SERVICE_ROLE_KEY` in frontend code.** It is only read by the API functions.

Then redeploy.

## 3. Import your Excel

Your Excel should contain:

| Name | Description | Image |
|---|---|---|
| Yagnik | Hello | https://example.com/photo.jpg |
| Rahul | A great teammate... | https://... |

Open:

`https://YOUR-VERCEL-DOMAIN.vercel.app/admin.html`

Sign in with the Supabase user created for you.

Choose **IMPORT EXCEL** and select your `.xlsx` file.

The server reads the first worksheet and upserts the rows into Supabase.

## 4. Add photos

From the admin panel you can either:

- paste an existing image URL, or
- select a photo and press **UPLOAD PHOTO**.

The upload is sent to the protected server API and stored in Supabase Storage. The resulting public image URL is saved with that colleague's memory.

## 5. Your public link

After deployment Vercel gives you a URL similar to:

`https://badnam-gully-farewell.vercel.app`

Share that URL with colleagues.

Admin:

`https://badnam-gully-farewell.vercel.app/admin.html`

## Security model

Public:

```text
POST /api/lookup
       ↓
exact name match
       ↓
only matching record returned
```

Admin:

```text
Supabase Auth login
       ↓
Bearer access token
       ↓
server verifies user
       ↓
email must equal ADMIN_EMAIL
       ↓
admin API
       ↓
Supabase service role
```

There is intentionally no public endpoint such as `/api/people` that returns every colleague.

## Local development

```bash
npm install
vercel dev
```

Create a local `.env` using `.env.example` first.

## Important limitation

If a visitor already knows a colleague's name, they can intentionally query that name and receive the matching memory. The application prevents bulk roster exposure, but no web application can make information completely undiscoverable when the server intentionally returns it for a supplied identifier.

## Suggested farewell enhancements

The project is ready for additions such as:

- animated memory reveal
- background music toggle
- farewell countdown
- "memory unlocked" animation
- QR code for the public link
- custom domain such as `badnamgully.com`
- one-time visitor messages / guestbook
- confetti on a successful match
