create table if not exists public.people (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  name_key text generated always as (lower(regexp_replace(trim(name), '\\s+', ' ', 'g'))) stored,
  description text not null default '',
  image_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(name_key)
);

create index if not exists people_name_key_idx on public.people(name_key);

alter table public.people enable row level security;

-- Public visitors do NOT get table access. Lookups happen through the protected server API.
-- Authenticated users also do not get direct table access; the owner console uses the server API.

insert into storage.buckets (id, name, public)
values ('farewell-images', 'farewell-images', true)
on conflict (id) do nothing;

-- The storage bucket is public for image delivery, but uploads/deletes are performed by the server using the service role.
